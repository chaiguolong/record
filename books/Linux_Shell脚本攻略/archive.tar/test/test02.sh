#!/usr/bin/bash

echo "this is the second script";
